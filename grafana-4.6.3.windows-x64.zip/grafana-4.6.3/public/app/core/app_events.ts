///<reference path="../headers/common.d.ts" />

import {Emitter} from './utils/emitter';

var appEvents = new Emitter();
export default appEvents;
