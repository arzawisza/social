declare var CloudWatchDatasource: any;
export default CloudWatchDatasource;

